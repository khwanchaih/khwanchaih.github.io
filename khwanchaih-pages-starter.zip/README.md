# khwanchaih.github.io — Starter

This is a minimal, modern starter for your personal site on **GitHub Pages**.

## Quick start
1. Create repo named **khwanchaih.github.io** (public).
2. Upload these files (or push via git).
3. In the repo, go to **Settings → Pages** and set Source = `main` branch (root).
4. After it builds, open: https://khwanchaih.github.io

## Customize
- Edit content in `index.html` (About, Research, Projects, Contact).
- Replace the SVG avatar with your photo (e.g., `me.jpg`).
- Drop your `cv.pdf` in the repo and the “Download CV” button will work.
- To use a custom domain, add a `CNAME` file with your domain (e.g., `khwanchai.me`).

## Local development (optional)
```bash
git clone https://github.com/khwanchaih/khwanchaih.github.io
cd khwanchaih.github.io
# edit files, then:
git add . && git commit -m "Customize site" && git push
```
